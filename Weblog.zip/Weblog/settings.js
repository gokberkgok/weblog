module.exports = {
    OwnerIp : "",                 // your own IP (can be empty)
    secret : "9KYp3Za2L25vt7d1",  // It is a password to increase security, don't touch it if you don't know it
    databaseConfig: {             // Database settings
      host: "localhost",  
      user: "root",
      password: "",               // Database password
      database: "yourdatabasename"            // Database name
    }
};
